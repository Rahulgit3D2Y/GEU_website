<?php include("include/subheader.php"); ?>
      <!-- Title -->
      <title>About Us - DCA | GEU </title>
      <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 text-center ">
                <h1 class="text-center fw-bold display-4 mb-5">About us</h1>
            </div>    
        </div>
      </div>
  </section>


  <!-- about us -->
  <section class="about-us">

        <div class="about-col">
            <h1>We are the one who Transforms Dreams Into Reality </h1>     
            
            <a href="https://www.geu.ac.in" class="hero-btn red-btn">Explore Now</a>
        </div>
        <div class="about-col">
            <img src="images/geuHome.jpg">
        </div>
        
</section>
    </div>
  
  <?php
  include("include/footer.php");
  ?>
