<?php

$host="localhost";
$username="geumcain_geumca";
$password="geumcain_geumca";
$dbname="geumcain_geumca";
$con=mysqli_connect($host,$username,$password,$dbname) or die("<script language='javascript'>alert('Unable to connect to database');window.location='database/index.php'</script>");
/*
$host="localhost";
$username="root";
$password="";
$dbname="geumca";
$con=mysqli_connect($host,$username,$password,$dbname) or die("<script language='javascript'>alert('Unable to connect to database');window.location='database/index.php'</script>");*/


?>

