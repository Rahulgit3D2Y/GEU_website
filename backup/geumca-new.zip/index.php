<?php include("include/header.php"); ?>
      <!-- Title -->
      <div class="loader"></div>
  <script>
    window.addEventListener("load", () => {
    const loader = document.querySelector(".loader");

    loader.classList.add("loader--hidden");

    loader.addEventListener("transitionend", () => {
      document.body.removeChild(loader);
    });
  });
  </script>
      <div class="container-fluid">
        <div class="row" id="wel_head">
            
            <div class="col-lg-12 text-center ">
                <p class="font-weight-bold text-light" id="first-p">Department Of Computer Applications</p>
            </div>
            <div class="col-lg-12 text-center ">
                <p class="font-weight-bold text-white" id="first-p">Graphic Era (Deemed To Be University)</p>
            </div>
        </div>
        <div class="flexbtn">
          <div>
            <!--<a href="contact.php" class="btn btn-outline-light btn-lg">Connect with us</a>-->
          </div>
          
         
      </div>
      </div>
    

  </section>

 <!--images Carousel active class added using Jquery -->
 <div id="carouselExampleIndicators" class="carousel slide"data-interval="3000" data-ride="carousel">
    
    <div class="carousel-inner my-5" id="myCarousel">
 <?php
$count = 0;
$carouselquery=mysqli_query($con,"SELECT * FROM `carousel` WHERE `carousel_status`='Active' AND `carousel_display`='Active'  ORDER BY `carousel`.`carousel_id` DESC");
  while($carouselqueryresult=mysqli_fetch_assoc($carouselquery))
    {
        $carouselimagepath= $carouselqueryresult['carousel_file'];
        $carouselfilename="carousel_".$carouselqueryresult['carousel_session']."_".$carouselqueryresult['carousel_filealt'];
        if($carouselimagepath)
        {
$carouselimageencode = "admin/upload/carousel/$carouselimagepath";
     }
     else
     {
       $carouselimageencode = "admin/upload/carousel/NacA+.jpg";
     }
// Read image path, convert to base64 encoding
  $carouselimageData = base64_encode(file_get_contents($carouselimageencode));
// Format the image SRC:  data:{mime};base64,{data};
  $carouselimageencodesrc = 'data:'.mime_content_type($carouselimageencode).';base64,'.$carouselimageData;
  $count+=1;  ?>
      <div class="carousel-item">
              <a <?php if($carouselqueryresult['carousel_filelink']) { ?> href="<?php echo $carouselqueryresult['carousel_filelink']; ?>" target="_blank" <?php } ?>  > <img class="d-block w-100" src="<?php echo $carouselimageencodesrc; ?>" alt="<?php echo $carouselfilename; ?>"></a>
              </div>
           <?php } ?>
     
    </div>
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>

  <!-- jquery for adding the active class -->
  <script>$('#myCarousel').find('.carousel-item').first().addClass('active');</script>


  
<!-- Course offered -->
 
<section >
  <h1>Courses Offered</h1>
  <p>Department of computer applications</p>
  <br>
  <div class="course-card">
      <div class="course-col">
    <h3>MCA</h3> 
    <p>Master of Computer Applications</p>
  </div>
      <div class="course-col">
    <h3>M.Sc IT</h3> 
    <p>Master of Science Information Technology</p>
  </div>
    <div class="course-col">
    <h3>BCA</h3> 
    <p>Bachelor's of Computer Applications</p>
  </div>
  <div class="course-col">
    <h3>B.Sc. IT</h3> 
    <p>Bachelor's of Information Technology</p>
  </div>
  <div class="course-col">
    <h3>B.Sc. CS</h3> 
    <p>Bachelor's of Computer Science</p>
  </div>
  
  
  </div>
</section>

  <!--carousel Career opportunity -->
   <div class="col-lg-12">
      <h1 class="text-center fw-bold display-4.2 mb-4">Career Prospects</h1>
     <!-- <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Explicabo, quaerat?</p>-->
  </div>

  <div class="container-fluid my-5 ">
    <div class="row">
        <div class="col-12 m-auto">
            <div class="owl-carousel owl-theme">
                <div class="item mb-4">
                    <div class="card border-0 shadow">
                        <img src="https://source.unsplash.com/1200x800/?Full Stack Developer" alt="Full Stack Developer" class="card-img-top" >
                        <div class="card-body">
                            <div class="card-title text-center">
                             <h4>Full Stack Developer</h4>
                                 <!--  <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem quos tempore ipsam in nesciunt totam officia eius.</p>-->
                            </div>
                        </div>
                    </div>
                </div>

                <div class="item">
                    <div class="card border-0 shadow">
                        <img src="https://source.unsplash.com/1200x800/?Software Engineer" alt="Software Engineer" class="card-img-top">
                        <div class="card-body">
                            <div class="card-title text-center">
                                <h4>Software Engineer</h4>
                                 <!--  <p>Lorem ipsum dolor sit amet nesciunt totam officia eius.</p>-->
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="card border-0 shadow">
                        <img src="https://source.unsplash.com/1200x800/?Data Analyst" alt="Data Analyst" class="card-img-top" >
                        <div class="card-body">
                            <div class="card-title text-center">
                                <h4>Data Analyst</h4>
                                  <!-- <p>Lorem ipsum dolor sit amet consectetur aditotam officia eius.</p>-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>




  <!-- Call to Action -->

  <section class="colored-section my-5 p-4" id="cta">

    <div class="container">

      <h3 class="heading">Explore More With Department Of Computer Appilcations
        Join Us</h3>
      
    </div>
  </section>
      </div>

      
<!-- Button for the Top -->

<button onclick="topFunction()" id="myBtn" title="Go to top"></button>
<script>
    // Get the button
    let mybutton = document.getElementById("myBtn");

    // When the user scrolls down 20px from the top of the document, show the button
    window.onscroll = function() {scrollFunction()};

    function scrollFunction() {
      if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        mybutton.style.display = "block";
      } else {
        mybutton.style.display = "none";
      }
    }

    // When the user clicks on the button, scroll to the top of the document
    function topFunction() {
     document.body.scrollTop = 0;
     document.documentElement.scrollTop = 0;
    }
</script>
    <?php include("include/footer.php"); ?>
